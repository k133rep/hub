from resources.lib.externals.hachoir.hachoir_parser.program.elf import ElfFile
from resources.lib.externals.hachoir.hachoir_parser.program.exe import ExeFile
from resources.lib.externals.hachoir.hachoir_parser.program.python import PythonCompiledFile
from resources.lib.externals.hachoir.hachoir_parser.program.java import JavaCompiledClassFile
from resources.lib.externals.hachoir.hachoir_parser.program.prc import PRCFile

